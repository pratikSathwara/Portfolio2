/* Scroll Down Start  */
$(document).ready(function(){
  $(".ct-btn-scroll").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    } 
  });

$('#homeslider').owlCarousel({
    loop:true,
    autoplay:true,
    items:1
});
});



$(document).ready(function(){
  
	// SLIDER
	//$('.slider').slick({});
		
  $('.slider').slick({
    dots: true,
    speed: 1000,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    nextArrow: false,
    prevArrow: false,
  });
  $('.client').slick({
    dots: true,
    speed: 1000,
    infinite: true,
    // autoplay: true,
    autoplaySpeed: 3000,
    nextArrow: false,
    prevArrow: false,
  });
  $('.service').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    centerMode: true,
    arrows: true,
    dots: false,
    speed: 500,
    infinite: true,
    autoplaySpeed: 5000,
    // autoplay: true,
    nextArrow: '<div class="slick-custom-arrow slick-custom-arrow-right"><img src="/assets/image/next-grey.png" alt=""></div>',
    prevArrow: '<div class="slick-custom-arrow slick-custom-arrow-left"><img src="/assets/image/prev-grey.png" alt=""></div>',
              responsive: [                        
              {
                breakpoint: 576,settings: {
                slidesToShow: 1,}
              },
              {
                breakpoint: 768,settings: {
                slidesToShow: 2,}
              },
              {
                breakpoint: 991,settings: {
                slidesToShow: 4,}
              },
          ]
  });
});